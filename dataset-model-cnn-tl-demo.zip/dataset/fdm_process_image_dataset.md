# FDM Process Image Dataset, v1

- Total: 327 images
    - Normal case: 161 images
    - Defective case (Spaghetti-shape error): 166 images  
    
    ![](/dataset/sample_images.jpg)
